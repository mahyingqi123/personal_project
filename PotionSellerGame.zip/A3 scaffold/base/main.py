if not 1>1 and 1 != 2:
    print("dorcas is smart")
else:
    print("dorcas is dumb")




